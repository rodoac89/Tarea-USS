package model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {
    private static UserDAO instance;
    private Connection connection;

    private UserDAO() {
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection("jdbc:sqlite:usuarios.db");
            createTable();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static synchronized UserDAO getInstance() {
        if (instance == null) {
            instance = new UserDAO();
        }
        return instance;
    }

    private void createTable() throws SQLException {
        String sql = "CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE, password TEXT NOT NULL, role TEXT NOT NULL, estado TEXT NOT NULL)";
        Statement stmt = connection.createStatement();
        stmt.execute(sql);
        stmt.close();
    }

    public void registerUser(User user) throws SQLException {
        String sql = "INSERT INTO users (username, password, role, estado) VALUES (?, ?, 'cliente', 'pendiente')";
        PreparedStatement pstmt = connection.prepareStatement(sql);
        pstmt.setString(1, user.getUsername());
        pstmt.setString(2, user.getPassword());
        pstmt.executeUpdate();
        pstmt.close();
    }

    public List<User> getPendingUsers() throws SQLException {
        
        String username = null;
        String password = null;
        String role = null;
        String estado = null;
        Long id = null;
        
        List<User> users = new ArrayList<>();
        String sql = "SELECT * FROM users WHERE estado = 'pendiente'";
        Statement stmt = connection.createStatement();
        ResultSet rs = stmt.executeQuery(sql);

        while (rs.next()) {
            User user = new User(username, password, role, estado, id);
            user.setId(rs.getLong("id"));
            user.setUsername(rs.getString("username"));
            user.setPassword(rs.getString("password"));
            user.setEstado(rs.getString("estado"));
            users.add(user);
        }

        rs.close();
        stmt.close();
        return users;
    }

    public void authorizeUser(Long id) throws SQLException {
        String sql = "UPDATE users SET estado = 'autorizado' WHERE id = ?";
        PreparedStatement pstmt = connection.prepareStatement(sql);
        pstmt.setLong(1, id);
        pstmt.executeUpdate();
        pstmt.close();
    }

    public void deleteUser(Long id) throws SQLException {
        String sql = "DELETE FROM users WHERE id = ?";
        PreparedStatement pstmt = connection.prepareStatement(sql);
        pstmt.setLong(1, id);
        pstmt.executeUpdate();
        pstmt.close();
    }
}
