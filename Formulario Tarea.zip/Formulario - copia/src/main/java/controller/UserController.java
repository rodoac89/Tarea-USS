package controller;

import model.User;
import model.UserDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet("/admin")
public class UserController extends HttpServlet {
    private UserDAO userDAO;

    @Override
    public void init() throws ServletException {
        userDAO = UserDAO.getInstance();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("login".equals(action)) {
            request.getRequestDispatcher("/WEB-INF/jsp/admin_login.jsp").forward(request, response);
        } else if ("dashboard".equals(action)) {
            try {
                List<User> pendingUsers = userDAO.getPendingUsers();
                request.setAttribute("pendingUsers", pendingUsers);
                request.getRequestDispatcher("/WEB-INF/jsp/admin_dashboard.jsp").forward(request, response);
            } catch (SQLException ex) {
                Logger.getLogger(UserController.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else if ("register".equals(action)) {
            request.getRequestDispatcher("/WEB-INF/jsp/register.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String role = request.getParameter("role");
        String estado = request.getParameter("estado");

        if ("register".equals(action)) {
            User user = new User(username, password, role, estado, Long.parseLong("id"));
            user.setUsername(request.getParameter("username"));
            user.setPassword(request.getParameter("password"));
            try {
                userDAO.registerUser(user);
                response.sendRedirect("admin?action=login");
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if ("authorize".equals(action)) {
            Long id = Long.parseLong(request.getParameter("id"));
            try {
                userDAO.authorizeUser(id);
            } catch (Exception e) {
                e.printStackTrace();
            }
            response.sendRedirect("admin?action=dashboard");
        } else if ("delete".equals(action)) {
            Long id = Long.parseLong(request.getParameter("id"));
            try {
                userDAO.deleteUser(id);
            } catch (Exception e) {
                e.printStackTrace();
            }
            response.sendRedirect("admin?action=dashboard");
        }
    }
}
  