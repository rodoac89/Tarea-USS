package uss.ejemplo.ejemplosingleton;

import javax.swing.JButton;
import javax.swing.JFrame;
import uss.ejemplo.singleton.AdminPanel;
import uss.ejemplo.singleton.BaseDatos;
import uss.ejemplo.singleton.Cliente;

public class EjemploSingleton {
    public static void main(String[] args) {
        // Crear la tabla USUARIO si no existe
        BaseDatos.createTable();
        
        // Crear ventana principal
        JFrame frame = new JFrame("Sistema de Usuarios");
        frame.setSize(400, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        // Botón para registrar clientes
        JButton clienteBtn = new JButton("Registrar Cliente");
        clienteBtn.setBounds(50, 50, 150, 30);
        clienteBtn.addActionListener(e -> Cliente.main(null));

        // Botón para la interfaz del administrador
        JButton adminBtn = new JButton("Modo Administrador");
        adminBtn.setBounds(210, 50, 150, 30);
        // Aquí cambiamos el ActionListener para abrir la nueva ventana con la tabla
        adminBtn.addActionListener(e -> {
            AdminPanel adminPanel = new AdminPanel();
            adminPanel.setVisible(true);
        });

        // Añadir los botones a la ventana
        frame.add(clienteBtn);
        frame.add(adminBtn);

        frame.setVisible(true);
    }
}

