package uss.ejemplo.singleton;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class BaseDatos {
    
    // Método para conectar a la base de datos SQLite
    public static Connection connect() {
        String url = "jdbc:sqlite:usuarios.db"; // Archivo SQLite en el proyecto
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(url);
            System.out.println("Conexión establecida a SQLite.");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return conn;
    }

    // Método para crear la tabla USUARIO
    public static void createTable() {
        String sql = "CREATE TABLE IF NOT EXISTS USUARIO (\n"
                + " ID INTEGER PRIMARY KEY AUTOINCREMENT,\n"
                + " NOMBRE VARCHAR(50) NOT NULL,\n"
                + " APELLIDO VARCHAR(50) NOT NULL,\n"
                + " IS_STAFF BIT NOT NULL\n"
                + ");";

        try (Connection conn = connect();
             Statement stmt = conn.createStatement()) {
            // Ejecuta la creación de la tabla
            stmt.execute(sql);
            System.out.println("Tabla USUARIO creada.");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void main(String[] args) {
        // Llamar al método para crear la tabla cuando se ejecute el programa
        createTable();
    }
}