package uss.ejemplo.singleton;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Administrador {

    // Método para ver usuarios pendientes de autorización
    public static void verUsuariosPendientes() {
        String sql = "SELECT ID, NOMBRE, APELLIDO FROM USUARIO WHERE IS_STAFF = 0";

        try (Connection conn = BaseDatos.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("ID");
                String nombre = rs.getString("NOMBRE");
                String apellido = rs.getString("APELLIDO");
                int respuesta = JOptionPane.showConfirmDialog(null, "¿Autorizar a " + nombre + " " + apellido + "?");

                if (respuesta == JOptionPane.YES_OPTION) {
                    autorizarUsuario(id);
                } else if (respuesta == JOptionPane.NO_OPTION) {
                    eliminarUsuario(id);
                }
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    // Método para autorizar usuarios
    public static void autorizarUsuario(int id) {
        String sql = "UPDATE USUARIO SET IS_STAFF = 1 WHERE ID = ?";

        try (Connection conn = BaseDatos.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Usuario autorizado.");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    // Método para eliminar usuarios
    public static void eliminarUsuario(int id) {
        String sql = "DELETE FROM USUARIO WHERE ID = ?";

        try (Connection conn = BaseDatos.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Usuario eliminado.");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void main(String[] args) {
        verUsuariosPendientes();
    }
}
