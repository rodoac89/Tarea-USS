package uss.ejemplo.singleton;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Cliente {

    // Método para registrar un cliente en la base de datos
    public static void registrarCliente(String nombre, String apellido) {
        String sql = "INSERT INTO USUARIO(NOMBRE, APELLIDO, IS_STAFF) VALUES(?, ?, 0)";

        try (Connection conn = BaseDatos.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, nombre);
            pstmt.setString(2, apellido);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Registro exitoso. ¡Bienvenido " + nombre + "!");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void main(String[] args) {
        String nombre = JOptionPane.showInputDialog("Ingrese su nombre:");
        String apellido = JOptionPane.showInputDialog("Ingrese su apellido:");
        registrarCliente(nombre, apellido);
    }
}