/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package uss.ejemplo.singleton;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableCellEditor;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class AdminPanel extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;

    public AdminPanel() {
        // Configuración del JFrame
        setTitle("Panel de Administrador con Acciones");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Crear la tabla con los usuarios y las acciones
        String[] columnNames = {"ID", "Nombre", "Apellido", "Acción"};
        tableModel = new DefaultTableModel(columnNames, 0);
        table = new JTable(tableModel) {
            // Hacemos que la columna de botones use nuestro renderizador
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 3;  // Solo la columna de Acción será editable (con botones)
            }

            @Override
            public Class<?> getColumnClass(int column) {
                return column == 3 ? JButton.class : String.class;
            }
        };

        // Añadir el renderizador y editor de la columna de botones
        table.getColumnModel().getColumn(3).setCellRenderer(new ButtonRenderer());
        table.getColumnModel().getColumn(3).setCellEditor(new ButtonEditor(new JCheckBox()));

        // Cargar los usuarios
        cargarUsuarios();

        // Añadir la tabla a un JScrollPane
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);
    }

    // Método para cargar los usuarios desde la base de datos
    private void cargarUsuarios() {
        String sql = "SELECT * FROM USUARIO";

        try (Connection conn = BaseDatos.connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            // Limpiar la tabla antes de cargar nuevos datos
            tableModel.setRowCount(0);

            while (rs.next()) {
                int id = rs.getInt("ID");
                String nombre = rs.getString("NOMBRE");
                String apellido = rs.getString("APELLIDO");

                // Añadir fila con el botón de autorizar/denegar
                tableModel.addRow(new Object[]{id, nombre, apellido, "Autorizar/Denegar"});
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Renderizador para mostrar botones en la tabla
    class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer() {
            setOpaque(true);
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                                                       boolean isSelected, boolean hasFocus, int row, int column) {
            setText((value == null) ? "Autorizar/Denegar" : value.toString());
            return this;
        }
    }

    // Editor para manejar los clics en los botones
    class ButtonEditor extends DefaultCellEditor {
        protected JButton button;
        private String label;
        private boolean isPushed;
        private int row;

        public ButtonEditor(JCheckBox checkBox) {
            super(checkBox);
            button = new JButton();
            button.setOpaque(true);
            button.addActionListener((ActionEvent e) -> {
                fireEditingStopped();
            });
        }

        @Override
        public Component getTableCellEditorComponent(JTable table, Object value,
                                                     boolean isSelected, int row, int column) {
            this.row = row;
            label = (value == null) ? "Autorizar/Denegar" : value.toString();
            button.setText(label);
            isPushed = true;
            return button;
        }

        @Override
        public Object getCellEditorValue() {
            if (isPushed) {
                // Acciones cuando se presiona el botón
                int userId = (int) tableModel.getValueAt(row, 0);  // ID del usuario seleccionado
                String nombre = (String) tableModel.getValueAt(row, 1);
                String apellido = (String) tableModel.getValueAt(row, 2);

                // Mostrar opciones de autorizar o denegar
                int option = JOptionPane.showConfirmDialog(button, "¿Deseas autorizar a " + nombre + " " + apellido + "?", 
                        "Confirmación", JOptionPane.YES_NO_OPTION);

                if (option == JOptionPane.YES_OPTION) {
                    // Lógica para autorizar el usuario (puedes actualizar la BD aquí)
                    autorizarUsuario(userId);
                } else {
                    // Lógica para denegar el usuario (puedes actualizar la BD aquí)
                    denegarUsuario(userId);
                }
            }
            isPushed = false;
            return label;
        }

        @Override
        public boolean stopCellEditing() {
            isPushed = false;
            return super.stopCellEditing();
        }

        public void autorizarUsuario(int userId) {
            String sql = "UPDATE USUARIO SET IS_STAFF = 1 WHERE ID = ?";
            try (Connection conn = BaseDatos.connect();
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, userId);
                pstmt.executeUpdate();
                JOptionPane.showMessageDialog(button, "Usuario autorizado.");
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(button, "Error al autorizar usuario.");
            }
        }

        public void denegarUsuario(int userId) {
            String sql = "UPDATE USUARIO SET IS_STAFF = 0 WHERE ID = ?";
            try (Connection conn = BaseDatos.connect();
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, userId);
                pstmt.executeUpdate();
                JOptionPane.showMessageDialog(button, "Usuario denegado.");
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(button, "Error al denegar usuario.");
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            AdminPanel adminPanel = new AdminPanel();
            adminPanel.setVisible(true);
        });
    }
}

