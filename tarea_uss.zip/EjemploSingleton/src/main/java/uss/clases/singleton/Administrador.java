
package uss.clases.singleton;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Administrador {
    private static Administrador instancia;
    private Connection connection;

    // Constructor privado para evitar instanciación externa
    private Administrador() {
        try {
            this.connection = DriverManager.getConnection("jdbc:sqlite:usuarios.db");
            crearTabla();  // Llamar al método para crear la tabla al inicializar
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para obtener la instancia única
    public static Administrador getInstancia() {
        if (instancia == null) {
            instancia = new Administrador();
        }
        return instancia;
    }

    // Método para crear la tabla
    private void crearTabla() {
        String sql = "CREATE TABLE IF NOT EXISTS USUARIO (" +
                     "ID INTEGER PRIMARY KEY AUTOINCREMENT," +
                     "NOMBRE VARCHAR(50)," +
                     "APELLIDO VARCHAR(50)," +
                     "IS_STAFF BIT)";

        try (Statement stmt = getConnection().createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Usuario> verUsuariosPendientes() throws SQLException {
        List<Usuario> usuarios = new ArrayList<>();
        String query = "SELECT * FROM USUARIO WHERE IS_STAFF = 0";
        Statement stmt = getConnection().createStatement();
        ResultSet rs = stmt.executeQuery(query);
        
        while (rs.next()) {
            usuarios.add(new Usuario(rs.getInt("ID"), rs.getString("NOMBRE"), rs.getString("APELLIDO"), false));
        }
        
        return usuarios;
    }

    public void agregarUsuario(String nombre, String apellido) throws SQLException {
        String query = "INSERT INTO USUARIO (NOMBRE, APELLIDO, IS_STAFF) VALUES (?, ?, 0)";
        PreparedStatement pstmt = getConnection().prepareStatement(query);
        pstmt.setString(1, nombre);
        pstmt.setString(2, apellido);
        pstmt.executeUpdate();
    }

    public void quitarUsuario(int id) throws SQLException {
        String query = "DELETE FROM USUARIO WHERE ID = ?";
        PreparedStatement pstmt = getConnection().prepareStatement(query);
        pstmt.setInt(1, id);
        pstmt.executeUpdate();
    }

    public void autorizarUsuario(int id) throws SQLException {
        String query = "UPDATE USUARIO SET IS_STAFF = 1 WHERE ID = ?";
        PreparedStatement pstmt = getConnection().prepareStatement(query);
        pstmt.setInt(1, id);
        pstmt.executeUpdate();
    }

    /**
     * @param aInstancia the instancia to set
     */
    public static void setInstancia(Administrador aInstancia) {
        instancia = aInstancia;
    }

    /**
     * @return the connection
     */
    public Connection getConnection() {
        return connection;
    }

    /**
     * @param connection the connection to set
     */
    public void setConnection(Connection connection) {
        this.connection = connection;
    }
}