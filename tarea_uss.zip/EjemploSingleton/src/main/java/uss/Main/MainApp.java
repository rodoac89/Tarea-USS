package uss.Main;

import javax.swing.*;
import java.awt.event.*;
import java.sql.SQLException;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import uss.clases.singleton.Administrador;
import uss.clases.singleton.Cliente;
import uss.clases.singleton.Usuario;


import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.*;
import java.sql.SQLException;
import java.util.List;

public class MainApp {

    private static JTable table;
    private static DefaultTableModel tableModel;

    public static void main(String[] args) {
        JFrame frame = new JFrame("Sistema de Registro");
        
        // Panel para el login del administrador
        JPanel adminPanel = new JPanel();
        
        JButton btnLoginAdmin = new JButton("Login Admin");
        
        btnLoginAdmin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Administrador admin = Administrador.getInstancia();
                    List<Usuario> usuariosPendientes = admin.verUsuariosPendientes();
                    
                    // Limpiar el modelo de la tabla antes de llenarlo
                    tableModel.setRowCount(0);
                    
                    for (Usuario usuario : usuariosPendientes) {
                        tableModel.addRow(new Object[]{usuario.getId(), usuario.getNombre(), usuario.getApellido()});
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });
        
        adminPanel.add(btnLoginAdmin);
        
        // Panel para registro de cliente
        JPanel clientPanel = new JPanel();
        
        JTextField txtNombre = new JTextField(10);
        JTextField txtApellido = new JTextField(10);
        
        JButton btnRegistrarCliente = new JButton("Registrar Cliente");
        
        btnRegistrarCliente.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Administrador admin = Administrador.getInstancia();
                    admin.agregarUsuario(txtNombre.getText(), txtApellido.getText());
                    
                    Cliente cliente = new Cliente(txtNombre.getText(), txtApellido.getText());
                    cliente.saludo();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });
        
        clientPanel.add(txtNombre);
        clientPanel.add(txtApellido);
        clientPanel.add(btnRegistrarCliente);

        // Tabla para mostrar usuarios pendientes
        String[] columnNames = {"ID", "Nombre", "Apellido"};
        tableModel = new DefaultTableModel(columnNames, 0);
        table = new JTable(tableModel);

        // Botón para autorizar usuario seleccionado
        JButton btnAutorizar = new JButton("Autorizar Usuario");
        btnAutorizar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow >= 0) {
                    int userId = (int) tableModel.getValueAt(selectedRow, 0); // Obtener ID del usuario seleccionado
                    try {
                        Administrador admin = Administrador.getInstancia();
                        admin.autorizarUsuario(userId);
                        tableModel.removeRow(selectedRow); // Eliminar fila de la tabla
                        JOptionPane.showMessageDialog(frame, "Usuario autorizado.");
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                } else {
                    JOptionPane.showMessageDialog(frame, "Por favor selecciona un usuario.");
                }
            }
        });

        // Botón para quitar usuario seleccionado
        JButton btnQuitar = new JButton("Quitar Usuario");
        btnQuitar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow >= 0) {
                    int userId = (int) tableModel.getValueAt(selectedRow, 0); // Obtener ID del usuario seleccionado
                    try {
                        Administrador admin = Administrador.getInstancia();
                        admin.quitarUsuario(userId);
                        tableModel.removeRow(selectedRow); // Eliminar fila de la tabla
                        JOptionPane.showMessageDialog(frame, "Usuario eliminado.");
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                } else {
                    JOptionPane.showMessageDialog(frame, "Por favor selecciona un usuario.");
                }
            }
        });

        // Agregar componentes al marco
        frame.setLayout(new BoxLayout(frame.getContentPane(), BoxLayout.Y_AXIS));
        
        frame.add(adminPanel);
        frame.add(clientPanel);
        
        JScrollPane scrollPane = new JScrollPane(table);
        frame.add(scrollPane);
        
        frame.add(btnAutorizar);
        frame.add(btnQuitar);

        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}